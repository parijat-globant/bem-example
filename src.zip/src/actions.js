export function makeMenuItems(name){
	return {
		type : "MAKE_MENU",
		name: name
	}
}
